---
layout: default
title: Recursos
---

# Recursos útiles (España)

- **INCIBE 017** – Línea de ayuda y guías.
- **Oficina de Seguridad del Internauta (OSI)** – Avisos y materiales didácticos.
- **AEPD** – Protección de datos y brechas.
- **Maldita.es / Newtral / Verificat** – Verificación de bulos.
- **InVID/WeVerify** – Plugin para verificar vídeo/imagen.
- **Google Lens** – Búsqueda inversa de imágenes.

> Nota: Las credenciales de contenido (C2PA) ayudan, pero su ausencia no prueba falsedad ni su presencia garantiza veracidad.
