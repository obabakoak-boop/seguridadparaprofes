---
layout: default
title: Práctica — Checklist de hábitos
---

# Práctica: Checklist de hábitos (10 min)

**Objetivo:** Aterrizar 12 hábitos clave en el claustro.

## Pasos
Marca lo que ya cumples y fija fecha para lo pendiente.

- [ ] Bloqueo automático
- [ ] Cifrado de disco
- [ ] Sistema y apps al día
- [ ] Cuenta estándar
- [ ] Gestor de contraseñas
- [ ] 2FA app/llave
- [ ] Descargas oficiales
- [ ] Sin USB desconocidos
- [ ] Verificar enlaces
- [ ] Cautela en Wi‑Fi pública
- [ ] Copias 3‑2‑1 probadas
- [ ] RRSS: privacidad y prudencia

## Comprobación
- Foto del checklist firmado por el equipo/directiva.
