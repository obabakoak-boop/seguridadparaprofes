        ---
        layout: default
        title: Práctica — Redes sociales y desinformación
        ---

        # Práctica: Redes sociales y desinformación (15 min)

        **Objetivo:** Configurar privacidad y aprender a verificar contenidos.

        ## Pasos
        - [ ] Ajusta la **privacidad** de una red social (quién ve/comenta/etiqueta).
        - [ ] Activa **2FA** y revisa **sesiones abiertas**.
        - [ ] Haz una **búsqueda inversa** de una imagen viral.
        - [ ] (Opc.) Usa **InVID/WeVerify** para extraer 3 frames de un vídeo y buscarlos.

        ## Comprobación
        - Captura de ajustes de privacidad (sin datos sensibles).
- Enlace al origen de la imagen o captura del resultado.
