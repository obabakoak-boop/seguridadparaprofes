        ---
        layout: default
        title: Práctica — Protocolo de incidentes
        ---

        # Práctica: Protocolo de incidentes (10–15 min)

        **Objetivo:** Preparar respuesta rápida y ordenada.

        ## Pasos
        - [ ] Simula un incidente: correo de phishing abierto y fichero sospechoso.
- [ ] Ejecuta el protocolo: **aislar equipo**, **no borrar evidencias**, **cambiar contraseñas** desde otro dispositivo, **avisar** a Jefatura/DPO/Coord. TIC, **valorar** datos personales, **reportar** a plataforma/017 si procede.
- [ ] Documenta el incidente en una ficha (quién, cuándo, qué, acciones tomadas).

        ## Comprobación
        - Ficha del simulacro completada.
