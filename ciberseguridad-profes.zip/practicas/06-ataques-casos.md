---
layout: default
title: Práctica — Ataques comunes y casos famosos
---

# Práctica: Ataques comunes y casos famosos (10–15 min)

**Objetivo:** Entender vectores típicos y cómo cortarlos.

## Pasos
- [ ] Elige 2 casos (p. ej., ILOVEYOU y WannaCry) y resume **qué pasó** y **la lección**.
- [ ] Revisa tu **plan de copias** 3‑2‑1 y realiza una **restauración de prueba** de un archivo.
- [ ] Comprueba que el sistema y las apps están **parcheadas**.

## Comprobación
- Dos frases (una lección por caso).
- Evidencia de restauración correcta.
